# sveltekit-hello

Tiny example of a sveltekit app.

To quickly check it out, you can deploy the `sveltekit-hello.tar.gz` to your seelf instance.