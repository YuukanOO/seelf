# sveltekit-hello

Tiny example of a sveltekit app.
