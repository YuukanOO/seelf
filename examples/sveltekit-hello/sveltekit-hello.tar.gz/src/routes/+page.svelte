<div class="container">
	<div class="inner-container">
		<h1>Welcome aboard 🎉</h1>
		<p>Isn't that easy?</p>

		<ul>
			<li><a href="https://github.com/YuukanOO/seelf/" rel="noopener noreferrer">Source</a></li>
			<li>
				<a
					href="https://github.com/YuukanOO/seelf/blob/main/DOCUMENTATION.md"
					rel="noopener noreferrer">Docs</a
				>
			</li>
			<li><a href="https://liberapay.com/YuukanOO/" rel="noopener noreferrer">❤️ Donate</a></li>
		</ul>
	</div>
</div>

<style>
	* {
		margin: 0;
		padding: 0;
	}

	:global(html) {
		background-color: #010409;
		color: #8b949e;
		font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, Roboto,
			Helvetica Neue, Arial, Noto Sans, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji',
			Segoe UI Symbol, 'Noto Color Emoji';
	}

	.container {
		display: flex;
		justify-content: center;
		align-items: center;
		height: 100vh;
	}

	.inner-container {
		display: flex;
		flex-direction: column;
		align-items: center;
	}

	h1 {
		color: white;
	}

	ul {
		list-style-type: none;
		display: flex;
		margin-block-start: 1rem;
		gap: 1rem;
	}

	a {
		color: #10b981;
	}
</style>
